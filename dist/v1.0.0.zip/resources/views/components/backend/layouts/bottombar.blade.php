<footer class="footer text-center">
    Made with ♡ by
    <a href="{{ route('dashboard') }}">{{ $webName }}</a>.
</footer>
