<table>
    <thead>
    <tr>
        <th>Name</th>
        <th>Slug</th>
        <th>Created at</th>
        <th>Updated at</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($category->name); ?></td>
            <td><?php echo e($category->slug); ?></td>
            <td><?php echo e($category->created_at); ?></td>
            <td><?php echo e($category->updated_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/backend/export/xlsx/category.blade.php ENDPATH**/ ?>