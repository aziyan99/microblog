            <li class="sidebar-item">
                <a class="sidebar-link waves-effect waves-dark sidebar-link" href="javascript:;" wire:click="logout"
                   aria-expanded="false">
                    <i class="mdi mdi-logout"></i>
                    <span class="hide-menu">Logout</span>
                </a>
            </li>