<div class="about-page">
    <h3>About <?php echo e($settingData->name); ?></h3>
    <p>
        <?php echo e($settingData->name); ?> is <?php echo e($settingData->short_desc); ?>

    </p>
    <h4><u>Available at</u></h4>
    <ol>
        <li>Facebook: <a href="<?php echo e($settingData->facebook); ?>"><?php echo e($settingData->facebook); ?></a></li>
        <li>Youtube: <a href="<?php echo e($settingData->youtube); ?>"><?php echo e($settingData->youtube); ?></a></li>
        <li>Instagram: <a href="<?php echo e($settingData->instagram); ?>"><?php echo e($settingData->instagram); ?></a></li>
        <li>Phone: <a href="javascript:void(0);"><?php echo e($settingData->phone_number); ?></a></li>
        <li>Address: <a href="javascript:void(0);"><?php echo e($settingData->address); ?></a></li>
    </ol>
</div>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/livewire/frontend/about/index.blade.php ENDPATH**/ ?>