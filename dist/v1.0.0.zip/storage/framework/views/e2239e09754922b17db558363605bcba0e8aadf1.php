<footer class="footer text-center">
    Made with ♡ by
    <a href="<?php echo e(route('dashboard')); ?>"><?php echo e($webName); ?></a>.
</footer>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/components/backend/layouts/bottombar.blade.php ENDPATH**/ ?>