<?php $__env->startSection('title', 'Message'); ?>
<div class="row">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
        <div class="row">
            <div class="col-3">
                <button class="mt-3 mb-2 btn btn-danger text-light" wire:click="clearAllMessage">
                    <i class="mdi mdi-delete-forever me-2"></i>
                    Clear all message
                </button>
            </div>
        </div>
    <?php endif; ?>
    <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">
                    Inbox
                </h3>
                <h4 class="card-subtitle">Listing all of your inbox message</h4>
                <div class="list-group mt-3">
                    <?php $__empty_1 = true; $__currentLoopData = $inBoxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="javascript:;" wire:click="openInBox(<?php echo e($inbox->id); ?>)" class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1"><?php echo e($inbox->sender_name->name); ?></h5>
                            <small><?php echo e($inbox->created_at->diffForHumans()); ?></small>
                        </div>
                        <small><?php echo e(Str::limit($inbox->subject, 20, '...')); ?></small>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-muted">
                        <small><i>Inbox are empty</i></small>
                    </div>
                    <?php endif; ?>
                  </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">
                    Outbox
                </h3>
                <h4 class="card-subtitle">Listing all of your outbox message</h4>
                <div class="list-group mt-3">
                    <?php $__empty_1 = true; $__currentLoopData = $outBoxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="javascript:;" wire:click="openOutBox(<?php echo e($outbox->id); ?>)" class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1"><?php echo e($outbox->receiver_name->name); ?></h5>
                            <small><?php echo e($outbox->created_at->diffForHumans()); ?></small>
                        </div>
                        <small><?php echo e(Str::limit($outbox->subject, 20, '...')); ?></small>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-muted">
                            <small><i>Outbox are empty</i></small>
                        </div>
                    <?php endif; ?>
                  </div>
            </div>
        </div>
    </div>
    <div class="col-lg-8 col-md-8 col-sm-12">
        <?php if($isOutboxOpen): ?>
        <div class="card">
            <div class="card-body">
                <button class="btn btn-secondary" wire:click="closeAllBox">
                    <i class="mdi mdi-close-circle me-2"></i>
                    Close
                </button>
                <table class="table table-hover table-bordered mt-3">
                    <tr>
                        <th>Receiver</th>
                        <td><?php echo e($outboxMessage->receiver_name->name); ?></td>
                    </tr>
                    <tr>
                        <th>Subject</th>
                        <td><?php echo e($outboxMessage->subject); ?></td>
                    </tr>
                    <tr>
                        <th>message</th>
                        <td><?php echo e($outboxMessage->message); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <?php elseif($isInboxOpen): ?>
        <div class="card">
            <div class="card-body">
                <button class="btn btn-secondary" wire:click="closeAllBox">
                    <i class="mdi mdi-close-circle me-2"></i>
                    Close
                </button>
                <table class="table table-hover table-bordered mt-3">
                    <tr>
                        <th>Sender</th>
                        <td><?php echo e($inboxMessage->sender_name->name); ?></td>
                    </tr>
                    <tr>
                        <th>Subject</th>
                        <td><?php echo e($inboxMessage->subject); ?></td>
                    </tr>
                    <tr>
                        <th>message</th>
                        <td><?php echo e($inboxMessage->message); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <?php else: ?>
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">
                    Create new message
                </h3>
                <h4 class="card-subtitle">Compose new message to registered user in system</h4>

                <form class="mt-3" wire:submit.prevent="sendMessage">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label>To</label>
                                <select class="form-control <?php $__errorArgs = ['receiverId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="receiverId">
                                    <option value="">-- choose --</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->id != $senderId): ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['receiverId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="invalid-feedback" role="alert"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label>Subject</label>
                                <input type="text" wire:model="subject" class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="invalid-feedback" role="alert"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea wire:model="message" cols="30" rows="4" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="invalid-feedback" role="alert"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary" type="submit">
                                <i class="mdi mdi-send me-2"></i>
                                Send
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/livewire/backend/message/index.blade.php ENDPATH**/ ?>