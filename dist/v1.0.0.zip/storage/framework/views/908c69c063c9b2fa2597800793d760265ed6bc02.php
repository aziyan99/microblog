<div class="header">
    <span class="header-title"><?php echo e($setting->name); ?></span>&nbsp;<span class="header-subtitle"><?php echo e($setting->short_desc); ?></span>
</div>
<div class="menu-wrapper">
    <ul class="menu">
        <?php
            $name = Route::currentRouteName()
        ?>
        <li>
            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(($name == "home" || $name == "home.category") ? 'active' : ''); ?>">Home</a>
        </li>
        <li>
            <a href="<?php echo e(route('categories')); ?>" class="<?php echo e(($name == "categories") ? 'active' : ''); ?>">Category</a>
        </li>
        <li>
            <a href="<?php echo e(route('about')); ?>" class="<?php echo e(($name == "about") ? 'active' : ''); ?>">About</a>
        </li>
    </ul>
</div>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/components/frontend/layouts/topbar.blade.php ENDPATH**/ ?>