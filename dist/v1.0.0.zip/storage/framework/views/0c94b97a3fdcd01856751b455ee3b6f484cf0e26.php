<div class="detail-post">
    <h1><?php echo e($post->title); ?></h1>
    <p><?php echo e($post->created_at->diffForHumans()); ?>, <u><?php echo e($post->category->name); ?></u>, <u><?php echo e($post->user->name); ?></u>, <u><?php echo e($post->views); ?> views</u></p>
    <br>
    <img src="<?php echo e(asset('storage') . "/" . $post->thumbnail); ?>" alt="thumb" class="img-fluid mx-auto d-block">
    <br>
    <br>
    <?php echo $post->body; ?>

</div>
<div class="realted-posts">
    <hr>
    <h4>Related posts</h4>
    <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <small><?php echo e($related->title); ?>, <?php echo e($related->created_at->diffForHumans()); ?> <a href="<?php echo e(route('read', $related->slug)); ?>">more</a></small><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/livewire/frontend/read/index.blade.php ENDPATH**/ ?>