            <li class="sidebar-item">
                <a class="sidebar-link waves-effect waves-dark sidebar-link" href="javascript:;" wire:click="logout"
                   aria-expanded="false">
                    <i class="mdi mdi-logout"></i>
                    <span class="hide-menu">Logout</span>
                </a>
            </li><?php /**PATH /Users/rajaazian/Code/microblog/storage/framework/views/eca6ce32cd913a84a5d2680e57a728630a9431ff.blade.php ENDPATH**/ ?>