<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="robots" content="noindex,nofollow">
    <title><?php echo $__env->yieldContent('title'); ?> - Admin Area</title>
    <!-- Favicon icon -->
    <?php if (isset($component)) { $__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Backend\Layouts\Ico::class, []); ?>
<?php $component->withName('backend.layouts.ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5)): ?>
<?php $component = $__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5; ?>
<?php unset($__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('backend')); ?>/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php echo \Livewire\Livewire::styles(); ?>

    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js" defer></script>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>
<div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full"
     data-boxed-layout="full">
    <?php if (isset($component)) { $__componentOriginal0db37fdbb4b8153359b18f1653923d1a03c3d12c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Backend\Layouts\Topbar::class, []); ?>
<?php $component->withName('backend.layouts.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0db37fdbb4b8153359b18f1653923d1a03c3d12c)): ?>
<?php $component = $__componentOriginal0db37fdbb4b8153359b18f1653923d1a03c3d12c; ?>
<?php unset($__componentOriginal0db37fdbb4b8153359b18f1653923d1a03c3d12c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal4071e53ea1b2ae9ceeb2b2cab0d16ebba12e8bb6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Backend\Layouts\Sidebar::class, []); ?>
<?php $component->withName('backend.layouts.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4071e53ea1b2ae9ceeb2b2cab0d16ebba12e8bb6)): ?>
<?php $component = $__componentOriginal4071e53ea1b2ae9ceeb2b2cab0d16ebba12e8bb6; ?>
<?php unset($__componentOriginal4071e53ea1b2ae9ceeb2b2cab0d16ebba12e8bb6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <div class="page-wrapper">
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-5 align-self-center">
                    <h4 class="page-title"><?php echo $__env->yieldContent('title'); ?></h4>
                </div>
                <div class="col-7 align-self-center">
                    <div class="d-flex align-items-center justify-content-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="#">Home</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo $__env->yieldContent('title'); ?></li>
                                <li class="breadcrumb-item"><?php echo $__env->yieldContent('action'); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <?php echo e($slot); ?>

        </div>
        <?php if (isset($component)) { $__componentOriginalb18436e114963eec0b8b96332abb1af740271fec = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Backend\Layouts\Bottombar::class, []); ?>
<?php $component->withName('backend.layouts.bottombar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb18436e114963eec0b8b96332abb1af740271fec)): ?>
<?php $component = $__componentOriginalb18436e114963eec0b8b96332abb1af740271fec; ?>
<?php unset($__componentOriginalb18436e114963eec0b8b96332abb1af740271fec); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
</div>
<script src="<?php echo e(asset('backend')); ?>/assets/libs/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('backend')); ?>/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="<?php echo e(asset('backend')); ?>/assets/extra-libs/sparkline/sparkline.js"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('backend')); ?>/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(asset('backend')); ?>/js/custom.min.js"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/layouts/backend.blade.php ENDPATH**/ ?>