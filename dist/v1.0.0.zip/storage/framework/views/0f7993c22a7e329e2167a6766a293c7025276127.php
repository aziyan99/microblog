<aside class="left-sidebar" data-sidebarbg="skin5">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('dashboard')); ?>"
                       aria-expanded="false">
                        <i class="mdi mdi-av-timer"></i>
                        <span class="hide-menu">Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('home')); ?>" target="_blank"
                       aria-expanded="false">
                        <i class="mdi mdi-web"></i>
                        <span class="hide-menu">Home page</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('category.index')); ?>"
                       aria-expanded="false">
                        <i class="mdi mdi-pin"></i>
                        <span class="hide-menu">Category</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('post.index')); ?>"
                       aria-expanded="false">
                        <i class="mdi mdi-newspaper"></i>
                        <span class="hide-menu">Posts</span>
                    </a>
                </li><li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('message')); ?>"
                       aria-expanded="false">
                        <i class="mdi mdi-message"></i>
                        <span class="hide-menu">Message</span>
                        <span class="ms-2 badge bg-info"><?php echo e($inboxCount); ?></span>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('user.index')); ?>"
                       aria-expanded="false">
                        <i class="mdi mdi-account-multiple"></i>
                        <span class="hide-menu">Users</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('setting')); ?>"
                       aria-expanded="false">
                        <i class="mdi mdi-settings"></i>
                        <span class="hide-menu">Settings</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('profile')); ?>"
                       aria-expanded="false">
                        <i class="mdi mdi-account-network"></i>
                        <span class="hide-menu">Profile</span>
                    </a>
                </li>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.logout.index', [])->html();
} elseif ($_instance->childHasBeenRendered('2MX2EaB')) {
    $componentId = $_instance->getRenderedChildComponentId('2MX2EaB');
    $componentTag = $_instance->getRenderedChildComponentTagName('2MX2EaB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2MX2EaB');
} else {
    $response = \Livewire\Livewire::mount('auth.logout.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('2MX2EaB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/components/backend/layouts/sidebar.blade.php ENDPATH**/ ?>