<?php $__env->startSection('title', 'Post'); ?>
<?php $__env->startSection('action', 'Detail'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">
                    Posts detail
                </h4>
                <h5 class="card-subtitle">Detail of posts data</h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover mt-3 mb-3">
                        <tr>
                            <th>Title</th>
                            <td><?php echo e($post->title); ?></td>
                        </tr>
                        <tr>
                            <th>Slug</th>
                            <td><?php echo e($post->slug); ?></td>
                        </tr>
                        <tr>
                            <th>Category</th>
                            <td><?php echo e($post->category->name); ?></td>
                        </tr>
                        <tr>
                            <th>Created by</th>
                            <td><?php echo e($post->user->name); ?></td>
                        </tr>
                        <tr>
                            <th>Thumbnail</th>
                            <td>
                                <a href="<?php echo e(asset($post->thumbnail)); ?>" target="_blank">
                                    <img src="<?php echo e(asset($post->thumbnail)); ?>" alt="thumbnail" class="img-thumbnail" width="200">
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <th>Body</th>
                            <td>
                                <?php echo $post->body; ?>

                            </td>
                        </tr>
                    </table>
                </div>
                <a href="<?php echo e(route('post.index')); ?>" class="btn btn-secondary">
                    <i class="mdi mdi-arrow-left-bold-circle me-2"></i>
                    Back
                </a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/livewire/backend/post/detail.blade.php ENDPATH**/ ?>