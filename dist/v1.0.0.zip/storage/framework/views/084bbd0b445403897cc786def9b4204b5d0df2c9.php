<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if (isset($component)) { $__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Backend\Layouts\Ico::class, []); ?>
<?php $component->withName('backend.layouts.ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5)): ?>
<?php $component = $__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5; ?>
<?php unset($__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:ital,wght@0,100;0,300;1,100;1,300&display=swap"
          rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/custom/css/main.css">
    <?php echo \Livewire\Livewire::styles(); ?>

    <title><?php echo e($title); ?></title>
</head>

<body>
<div class="container mt-3">
    <div class="row">
        <div class="col-lg-7 mx-auto">
            <?php if (isset($component)) { $__componentOriginalcea49c6da23465a29228cb60a4f64a7a6172a188 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Frontend\Layouts\Topbar::class, []); ?>
<?php $component->withName('frontend.layouts.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcea49c6da23465a29228cb60a4f64a7a6172a188)): ?>
<?php $component = $__componentOriginalcea49c6da23465a29228cb60a4f64a7a6172a188; ?>
<?php unset($__componentOriginalcea49c6da23465a29228cb60a4f64a7a6172a188); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php echo $__env->yieldContent('main'); ?>
            <?php if (isset($component)) { $__componentOriginal2416e4ebee1e84ea4c8a085e8719a8759a650965 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Frontend\Layouts\Bottombar::class, []); ?>
<?php $component->withName('frontend.layouts.bottombar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2416e4ebee1e84ea4c8a085e8719a8759a650965)): ?>
<?php $component = $__componentOriginal2416e4ebee1e84ea4c8a085e8719a8759a650965; ?>
<?php unset($__componentOriginal2416e4ebee1e84ea4c8a085e8719a8759a650965); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('frontend')); ?>/assets/js/bootstrap.bundle.js"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/layouts/frontend.blade.php ENDPATH**/ ?>