<div class="content-wrapper">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="content">
            <h3><?php echo e($post->title); ?></h3>
            <small class="content-desc"><?php echo e($post->created_at->diffForHumans()); ?>, <u><?php echo e($post->category->name); ?></u>, <u><?php echo e($post->user->name); ?></u></small>
            <br>
            <br>
            <small><?php echo e(strip_tags(Str::limit($post->body, 200))); ?></small>
            <a href="<?php echo e(route('read', $post->slug)); ?>">more</a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->startPush('js'); ?>
    <script>
        window.onscroll = function(ev) {
            if((window.innerHeight + window.scrollY) >= document.body.offsetHeight){
                window.livewire.emit('load-more');
            }
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/livewire/frontend/home/index.blade.php ENDPATH**/ ?>