<table>
    <thead>
    <tr>
        <th>Title</th>
        <th>Slug</th>
        <th>Category</th>
        <th>Created by</th>
        <th>Body</th>
        <th>Views</th>
        <th>Created at</th>
        <th>Updated at</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->slug); ?></td>
            <td><?php echo e($post->category->name); ?></td>
            <td><?php echo e($post->user->name); ?></td>
            <td><?php echo e($post->body); ?></td>
            <td><?php echo e($post->views); ?></td>
            <td><?php echo e($post->created_at); ?></td>
            <td><?php echo e($post->updated_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/backend/export/xlsx/post.blade.php ENDPATH**/ ?>