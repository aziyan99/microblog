<?php $__env->startSection('title', 'Post'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">
                    Posts data
                </h4>
                <h5 class="card-subtitle">listing of all posts data</h5>
                <div class="row">
                    <div class="col-lg-6 col-md-12">
                        <a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary mt-3">
                            <i class="mdi mdi-plus-circle me-2"></i>
                            Create new post
                        </a>
                        <button type="button" wire:click="exportExcel" class="btn btn-secondary mt-3">
                            <i class="mdi mdi-file-excel me-2"></i>
                            Export excel
                        </button>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="row">
                            <div class="col-2">
                                <select wire:model="count" class="form-control align-middle mt-3 mb-3">
                                    <option value="5">5</option>
                                    <option value="10">10</option>
                                </select>
                            </div>
                            <div class="col-10">
                                <input type="text" wire:model="search" class="form-control align-middle mt-3 mb-3">
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered table-sm">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Created by</th>
                            <th>Views</th>
                            <th>Created at</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($post->id); ?></td>
                                <td><?php echo e($post->title); ?></td>
                                <td>
                                    <span class="badge bg-purple"><?php echo e($post->category->name); ?></span>
                                </td>
                                <td><?php echo e($post->user->name); ?></td>
                                <td>
                                    <span class="badge bg-megna"><?php echo e($post->views); ?></span>
                                </td>
                                <td><?php echo e($post->created_at->diffForHumans()); ?></td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $post)): ?>
                                        <a href="<?php echo e(route('post.edit', $post->id)); ?>" class="btn btn-warning text-light mb-2">
                                            <i class="mdi mdi-pencil-box-outline align-middle me-1"></i>
                                            edit
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('post.detail', $post->id)); ?>" class="btn btn-info text-light mb-2">
                                        <i class="mdi mdi-eye-outline align-middle me-1"></i>
                                        detail
                                    </a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $post)): ?>
                                        <?php if($destroyId != $post->id): ?>
                                            <button type="button" wire:click="setDestroyId(<?php echo e($post->id); ?>)" class="btn btn-danger mb-2 text-light">
                                                <i class="mdi mdi-delete align-middle me-1"></i>
                                                delete
                                            </button>
                                        <?php else: ?>
                                            <button type="button" wire:click="destroy" class="btn btn-danger text-light mb-2">
                                                <i class="mdi mdi-delete align-middle me-1"></i>
                                                delete this data?
                                            </button>
                                            <button type="button" wire:click="cancelDestroy" class="btn btn-secondary text-light mb-2">
                                                <i class="mdi mdi-repeat align-middle me-1"></i>
                                                cancel delete
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted"><i>Post data is empty</i></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($posts->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/livewire/backend/post/index.blade.php ENDPATH**/ ?>