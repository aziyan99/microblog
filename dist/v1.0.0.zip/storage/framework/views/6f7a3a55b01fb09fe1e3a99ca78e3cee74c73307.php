<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>login | admin area</title>
    <?php if (isset($component)) { $__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Backend\Layouts\Ico::class, []); ?>
<?php $component->withName('backend.layouts.ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5)): ?>
<?php $component = $__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5; ?>
<?php unset($__componentOriginal47d92090ff11dbd0f9d02f8f889aa458070643c5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('backend')); ?>/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-5 col-md-12 col-sm-12"></div>
        <div class="col-lg-2 col-md-12 col-sm-12">
            <?php echo $__env->yieldContent('main'); ?>
        </div>
        <div class="col-lg-5 col-md-12 col-sm-12"></div>
    </div>
</div>
<script src="<?php echo e(asset('backend')); ?>/assets/libs/jquery/dist/jquery.min.js"></script>
<script src="<?php echo e(asset('backend')); ?>/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH /Users/rajaazian/Code/microblog/resources/views/layouts/auth.blade.php ENDPATH**/ ?>